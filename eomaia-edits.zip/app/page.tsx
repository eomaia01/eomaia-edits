'use client';
import React from 'react';

export default function EomaiaEdits() {
  return (
    <div className="min-h-screen bg-zinc-900 text-white p-6">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold tracking-wider">EOMAIA EDITS</h1>
        <p className="text-zinc-400 mt-2">Portfólio de Edição de Vídeos por Gabriel Maia</p>
      </header>

      <section className="max-w-3xl mx-auto mb-12">
        <h2 className="text-2xl font-semibold mb-4">✨ Sobre mim</h2>
        <p className="text-zinc-300">
          Olá! Me chamo <strong>Gabriel Maia</strong>, mais conhecido como <strong>Maia</strong>, tenho <strong>21 anos</strong>, moro em <strong>São Paulo - SP</strong>, e sou apaixonado por edição de vídeos desde os meus <strong>14 anos</strong>. O que começou como uma curiosidade virou uma verdadeira paixão. Desde então, venho me aperfeiçoando cada vez mais, estudando, testando e desenvolvendo meu estilo. Até o momento, edito conteúdos principalmente para mim mesmo, mas agora estou abrindo espaço para novos projetos e parcerias profissionais.
        </p>
      </section>

      <section className="max-w-3xl mx-auto mb-12">
        <h2 className="text-2xl font-semibold mb-4">💻 O que eu edito?</h2>
        <ul className="list-disc list-inside text-zinc-300">
          <li>🎮 <strong>Gameplays</strong> – cortes dinâmicos, cenas empolgantes, ritmo envolvente</li>
          <li>🎥 <strong>Vlogs</strong> – storytelling leve, cortes suaves e boa ambientação</li>
          <li>📱 <strong>Shorts/Reels/TikToks</strong> – foco em impacto rápido e estética moderna</li>
        </ul>
      </section>

      <section className="max-w-3xl mx-auto mb-12">
        <h2 className="text-2xl font-semibold mb-4">📂 Amostra de vídeo</h2>
        <div className="aspect-w-16 aspect-h-9 mb-4">
          <iframe
            className="w-full h-64 rounded-xl"
            src="https://www.youtube.com/embed/SH5qDb2XZ6w"
            title="YouTube video player"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          ></iframe>
        </div>
        <a
          href="https://www.youtube.com/@eomaia01"
          target="_blank"
          className="text-blue-400 hover:underline"
        >
          Visite meu canal no YouTube
        </a>
      </section>

      <section className="max-w-3xl mx-auto mb-12">
        <h2 className="text-2xl font-semibold mb-4">🕐 Disponibilidade</h2>
        <ul className="list-disc list-inside text-zinc-300">
          <li>⏰ <strong>Horário flexível</strong> – posso adaptar minha agenda conforme o projeto</li>
          <li>🔍 <strong>Atencioso aos detalhes</strong> – gosto de entregar um trabalho bem feito</li>
          <li>🤝 <strong>Fácil comunicação</strong> – estou sempre aberto a feedbacks</li>
        </ul>
      </section>

      <section className="max-w-3xl mx-auto mb-16">
        <h2 className="text-2xl font-semibold mb-4">💬 Por que me escolher?</h2>
        <p className="text-zinc-300">
          Se você procura alguém que trabalha com <strong>amor pela edição</strong>, dedicação real e cobra um <strong>valor justo</strong> por um <strong>trabalho de qualidade</strong>, estou aqui pra isso! Vai ser um prazer editar seus vídeos e fazer parte do seu projeto.
        </p>
      </section>

      <footer className="text-center border-t border-zinc-700 pt-6 text-zinc-400">
        <h2 className="text-xl font-semibold mb-2">📩 Entre em contato</h2>
        <p>Email: <a href="mailto:bielmaia090@gmail.com" className="text-blue-400 hover:underline">bielmaia090@gmail.com</a></p>
        <p>Instagram: <a href="https://www.instagram.com/gabriel.maiaa01/" target="_blank" className="text-blue-400 hover:underline">@gabriel.maiaa01</a></p>
        <p>WhatsApp: <a href="https://wa.me/5511911588339" target="_blank" className="text-blue-400 hover:underline">(11) 91158-8339</a></p>
      </footer>
    </div>
  );
}

